README.txt file documenting a CPSC 221 programming project.

Please fill out each TODO item in the header but change nothing else,
particularly nothing before the colon ":" on each line!

=================== HEADER =======================

Student #1, Name: TODO
Student #1, ugrad.cs.ubc.ca login: TODO
Student #1, ID: TODO

Student #2, Name: TODO (or write "NONE")
Student #2, ugrad.cs.ubc.ca login: TODO (or write "NONE")
Student #2, ID: TODO (or write "NONE")

Team name (for fun!): TODO

Project: RackaBrackaStack

Acknowledgment that you understand and have followed the course's
collaboration policy (READ IT at
http://www.ugrad.cs.ubc.ca/~cs221/current/syllabus.shtml#conduct):

Signed: TODO (put your names here again as a signature)

=================== BODY =======================

Plese fill in each of the following:

Approximate hours on Milestone: TODO

Approximate hours on Final Submission: TODO (when you get there)

Acknowledgment of assistance (per the collab policy!): TODO

For teams, rough breakdown of work: TODO (no more than a paragraph needed!)

What's the most useful tool or idea you learned on this project? 

TODO (no more than a paragraph needed)

What was the most frustrating issue to resolve on this project? 

TODO (no more than a paragraph needed)


TODO: Document any additional issues about your submission you feel
might be important.
